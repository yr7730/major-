# Pacemaker-Project

A programmable pacemaker implemented through Model-Driven-Design in **MATLAB Simulink**.

Acompanied with a device-control-module developed in **Python**.

> Just Added
> - serial communication between DCM and pacemaker

